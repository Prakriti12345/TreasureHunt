<!DOCTYPE html>
<html>
<head>
<title>Treasure Hunt</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="myPage">

<!-- Sidebar on click -->
<nav class="w3-sidebar w3-bar-block w3-white w3-card w3-animate-left w3-xxlarge" style="display:none;z-index:2" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-display-topright w3-text-teal">Close
    <i class="fa fa-remove"></i>
  </a>
  <a href="TreasureHunt/shopping.php" class="w3-bar-item w3-button">Subscribe</a>
  <a href="TreasureHunt/index.php" class="w3-bar-item w3-button">Login</a>
  <a href=""TreasureHunt/index.php" class="w3-bar-item w3-button">Homepage</a>
</nav>

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-hover-white w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="http://localhost/TreasureHunt/index.php" class="w3-bar-item w3-button w3-teal"><i class="fa fa-home w3-margin-right"></i>TH</a>
  <a href="#team" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Team</a>
  <a href="#work" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Work</a>
  <a href="#pricing" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Price</a>
  <a href="#contact" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
    
    </div>
  </div>
  <a href="http://localhost/TreasureHunt/shopping.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-hover-teal" title="Search"><i class="fa fa-search"></i></a>
 </div>

  <!-- Navbar on small screens -->
  <div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium">
    <a href="#team" class="w3-bar-item w3-button">Team</a>
    <a href="#work" class="w3-bar-item w3-button">Work</a>
    <a href="#pricing" class="w3-bar-item w3-button">Price</a>
    <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    <a href="#" class="w3-bar-item w3-button">Search</a>
  </div>
</div>

<!-- Image Header -->
<div class="w3-display-container w3-animate-opacity">
  <img src="images/TreasureHuntlogo.png" alt="boat" style="width:100%;min-height:550px;max-height:600px;">
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  
    <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-xlarge w3-theme w3-hover-teal" title="Go To W3.CSS">ABOUT US </button>
  </div>
</div>

<!-- Modal -->
<div id="id01" class="w3-modal">
  <div class="w3-modal-content w3-card-4 w3-animate-top">
    <header class="w3-container w3-teal w3-display-container"> 
      <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-teal w3-display-topright"><i class="fa fa-remove"></i></span>
      <h4>Hello Welcome to Treasure Hunt</h4>
      <h5>Join us Today<i class="fa fa-smile-o"></i></h5>
    </header>
    <div class="w3-container">
      <p>Cool huh? Here is our signup page </p>
      <p>Go to our <a class="w3-text-teal" href="http://localhost/TreasureHunt/subscribe.php">Find Hidden Treasures</a> Let the thrifting begin..</p>
    </div>
    <footer class="w3-container w3-teal">
  
    </footer>
  </div>
</div>

<!-- Team Container -->
<div class="w3-container w3-padding-40 w3-center" id="team">
<h2>OUR TEAM</h2>
<p>Meet the team </p>

<div class="w3-row"><br>

<div class="w3-quarter">
  <img src="images/prakriti.jpg" alt="Boss" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Prakriti Upadhyay Wagle</h3>
  <p>Web Designer</p>
</div>

<div class="w3-quarter">
  <img src="images/tom.jfif" alt="Boss" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Dinesh Khadka</h3>
  <p>Web Designer</p>
</div>


<div class="w3-quarter">
  <img src="images/priya.jfif" alt="Boss" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Priya Pokharel</h3>
  <p>Tester</p>
</div>
<div class="w3-quarter">
  <img src="images/ahmer.jfif" alt="Boss" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Ahmer Akbar </h3>
  <p>Analyst</p>
</div>

<div class="w3-quarter">
  <img src="images/haseeb.jfif" alt="Boss" style="width:55%" class="w3-circle w3-hover-opacity">
  <h3>Haseeb Ahmer</h3>
  <p>IT Support</p>
</div>

</div>
</div>

<!-- Work Row -->
<div class="w3-row-padding w3-padding-64 w3-theme-l1" id="work">

<div class="w3-quarter">
<h2>Our Work</h2>
<p>Treasure Hunt, an online Thrift store for both men and women. This online store consists of good condition used clothes, bags, accessories, and shoes at affordable prices. The main motive of the store is to sell used merchandise products at discounted prices. This online store can be accessed via a website from any part of Australia.</p>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <img src="images/jeans.png" alt="Snow" style="width:100%">
  <div class="w3-container">
  <h3>INA</h3>
 
  <p>Loved the dress</p>
  
  </div>
  </div>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <img src="images/pic4.png" alt="Lights" style="width:100%">
  <div class="w3-container">
  <h3>Family</h3>
 
  <p>My triplets are looking great.</p>
  
  </div>
  </div>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <img src="images/pic3.png" alt="Mountains" style="width:100%">
  <div class="w3-container">
  <h3>John</h3>
 
 
  <p>Shoes were great and great condition</p>
  </div>
  </div>
</div>

</div>


   

<!-- Contact Container -->
<div class="w3-container w3-padding-64 w3-theme-l5" id="contact">
  <div class="w3-row">
    <div class="w3-col m5">
    <div class="w3-padding-16"><span class="w3-xlarge w3-border-teal w3-bottombar">Contact Us</span></div>
      <h3>Address</h3>
      <p>Be a customer or Contributor. We welcome donations</p>
      <p><i class="fa fa-map-marker w3-text-teal w3-xlarge"></i> Darlinghust, Sydney</p>
      <p><i class="fa fa-phone w3-text-teal w3-xlarge"></i>  024567890</p>
      <p><i class="fa fa-envelope-o w3-text-teal w3-xlarge"></i>  WWW.TreasureHunt.store.au</p>
    </div>
    <div class="w3-col m7">
      <form class="w3-container w3-card-4 w3-padding-16 w3-white" action="http://localhost/TreasureHunt/index.php" target="_blank">
      
<div class="w3-section"> 
     
        <label>Name<span style="color:#ff0000">*</label>
        <input class="w3-input" type="text" name="Name" required>
      </div>
          
<div class="w3-section"> 
        <label>Email<span style="color:#ff0000">*</span></b></label>
    <input type="email"  class="w3-input" name="email" required >
      </div>

      <div class="w3-section">      
        <label>Message<span style="color:#ff0000">*</label>

        <input class="w3-input" type="text" name="Message" required>
      </div>  
      <input class="w3-check" type="checkbox" checked name="Like">
      <label>I Like it!</label>

       <div class="clearfix">
    
      <button type="submit" class="signupbtn">Submit</button>
    </div>
      </form>
    </div>
  </div>
</div>

<!-- Image of location/map -->
<img src="/w3images/map.jpg" class="w3-image w3-greyscale-min" style="width:100%;">

<!-- Footer -->
<footer class="w3-container w3-padding-32 w3-theme-d1 w3-center">
  <h4>Follow Us</h4>
  <a class="w3-button w3-large w3-teal" href="javascript:void(0)" title="Facebook"><i class="fa fa-facebook"></i></a>
 
  <div style="position:relative;bottom:100px;z-index:1;" class="w3-tooltip w3-right">
    <span class="w3-text w3-padding w3-teal w3-hide-small">Go To Top</span>   
    <a class="w3-button w3-theme" href="#myPage"><span class="w3-xlarge">
    <i class="fa fa-chevron-circle-up"></i></span></a>
  </div>
</footer>

<script>
// Script for side navigation
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "300px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}

// Close side navigation
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>

</body>
</html>
