<!DOCTYPE html>
<html>
<head>
<title>insert data</title>
</head>
<body>
<centre>


<?php



$conn = mysqli_connect('localhost', 'root', '','treasurehunt');

if($conn === false){
die("ERROR".mysqli_connect_error());}


$fn = mysqli_real_escape_string($conn, $_POST["fn"]);
$ln = mysqli_real_escape_string($conn, $_POST["ln"]);
$un = mysqli_real_escape_string($conn, $_POST["un"]);
$email = mysqli_real_escape_string($conn, $_POST["email"]);
$bday = mysqli_real_escape_string($conn, $_POST["bday"]);
$phone= mysqli_real_escape_string($conn, $_POST["phone"]);
$psw = mysqli_real_escape_string($conn, $_POST["psw"]);
$pswrepeat = mysqli_real_escape_string($conn, $_POST["psw-repeat"]);
$addressline1 = mysqli_real_escape_string($conn, $_POST["address-line1"]);
$postalcode= mysqli_real_escape_string($conn, $_POST["postal-code"]);
$country = mysqli_real_escape_string($conn, $_POST["country"]);


// database insert SQL code
$sql = "INSERT INTO signup  (FirstName, LastName, Username, Email, birthday, PhoneNumber, Password, RepeatPassword,Address,ZIP,Country) VALUES ('$fn', '$ln', '$un', '$email','$bday', '$phone', '$psw','$psw-repeat', '$addressline1', '$postalcode', '$country')";

 if(mysqli_query($conn, $sql)){
            echo "<h3>WELCOME TO TREASURE HUNT.</h3>
<p><b>Here are your entered details.</b></p>";
 
            echo nl2br("\n$fn\n $ln\n "
                . "$un\n $email\n $bday\n $phone\n $psw\n $pswrepeat\n $addressline1\n $postalcode\n $country\n");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);

        }
         
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>