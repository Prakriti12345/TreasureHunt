

<!DOCTYPE html>
<html>
<style>

     
/* Full-width input fields */

input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
 background-image:images/logo.png;

}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;

}


hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 20px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 40%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
h: 1px;
  height: 1px;
  left: -10000px;
  overflow: hidden;
}

.control, fieldset {
  margin: 6px 0;
}

label {
  display: inline.visually-hidden {
  position: absolute;
  widt-block;
  width: 120px;
  vertical-align: top;
}



/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}

h: 1px;
  height: 1px;
  left: -10000px;
  overflow: hidden;
}

.control, fieldset {
  margin: 6px 0;
}

label {
  display: inline.visually-hidden {
  position: absolute;
  widt-block;
  width: 120px;
  vertical-align: top;
}

  .required:after {
    content:" *";
    color: red;
  }


</style>


<body> 





<form action="connect.php" method="post" style="border:50px solid Black"  >
 <img class="w3-image" src="images/logo.png" alt="Thift Store" width="400" height="300" float=>
<div class="w3-display-left w3-padding-large"></div>
<div class="item active" >
  <div class="container" >
 
    <h1 style="color:Tomato;"><b> Welcome to Treasure Hunt </b></h1>
    <p style="color:Orange;"><b>Please fill in this form to create an account.</b></p>
    <hr>

 <label for="fn"><b>First Name<span style="color:#ff0000">*</span></b></label>
    <input type="text" placeholder="Enter First Name" name="fn" required ></hr>

 <hr><label for="ln"><b>Last Name<span style="color:#ff0000">*</span></b></label>
    <input type="text" placeholder="Enter Last Name" name="ln" required ></hr>

 <hr><label for="username"><b>Username<span style="color:#ff0000">*</span></b></label>
    <input type="text" placeholder="What should we call you?" name="un" required ></hr>

 <hr>   <label for="email"><b>Email<span style="color:#ff0000">*</span></b></label>
    <input type="email"  placeholder="Enter Email" name="email" required ></hr>

 <hr><label for = "birthday"> <b> Enter your birthday<span style="color:#ff0000">*</span> </b> </label>
    <input type="date"  name="bday" required pattern="\d{4}-\d{2}-\d{2}" required ></hr>
   

<hr><label for="phone"><b>Enter your phone number:<span style="color:#ff0000">*</span></B></label>
<input type="text"  placeholder=" Australian Mobile Number." id="phone" name="phone" ></hr>


   <hr> <label for="psw"><b>Password<span style="color:#ff0000">*</span></b></label>
    <input type="password" placeholder="Enter Password" name="psw" required ></hr>


  <hr>  <label for="psw-repeat"><b>Repeat Password<span style="color:#ff0000">*</span></b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required ></hr>


    <hr>  <!-- Alternative address format -->
         
      <section>
        <label for="address-line1">Address line 1<span style="color:#ff0000">*</span></label>
        <input required="" autocomplete="address-line1" id="address-line1" name="address-line1">
      </section>
    

     <hr> <section>
        <label for="postal-code">ZIP or postal code (optional)</label>
        <input id="postal-code" name="postal-code" autocomplete="postal-code" maxlength="20">
      </section></hr>

     <hr> <section id="country-region">
        <label for="country">Country or region<span style="color:#ff0000">*</span></label>
        <select id="country" name="country" autocomplete="country" enterkeyhint="done" required >
          
            <option value="AU">Australia</option>
           
          
        </select>  
     </hr>

  
    
  <hr>  <label>
      <input type="checkbox" checked="checked" name="Agree" style="margin-bottom:15px"> Acceptance of Terms of Use and Privacy Policy
    </label></hr>
    
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
  </div>
 <p>
    <span style="color:#ff0000">* REQUIRED</span>
  </p>
</form>

</body>
</html>
