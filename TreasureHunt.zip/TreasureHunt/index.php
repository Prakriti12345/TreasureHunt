
<?php include ('include/config.php');?>
<html>
<head>


  <link href="css/style.css">
  <title>Treasure Hunt</title>

</head>
<body>
<?php include ('templates/header.php'); ?>
<?php include ('templates/menu.php'); ?>



<?php include ('templates/footer.php'); ?>
</body>
</html>