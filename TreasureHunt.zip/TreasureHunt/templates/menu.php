<body class="w3-light-grey">

<!-- Navigation bar with social media icons -->
<div class="w3-bar w3-black w3-hide-small">
  <p><button type="button" onclick="document.getElementById('login').style.display='block'" class="w3-button w3-block  w3-quarter w3-right"></button></p>
 
     
</div>
  
  

<div class="w3-content" style="max-width:2000px">

  <!-- Header -->
  <header class="w3-container  w3-padding-80 w3-white ">
    <h1 class="w3-xxxlarge"><b></b>    <a href="http://localhost/TreasureHunt/Aboutus.php" class="w3-button w3-skyblue w3-padding-large w3-large w3-opacity w3-hover-opacity-off w3-left">ABOUT US</i></a>  

    <a href="http://localhost/TreasureHunt/subscribe.php" class="w3-button w3-skyblue w3-padding-large w3-large w3-opacity w3-hover-opacity-off w3-left"> Sign  UP </i></a>  </h1>
    <h6>Welcome to the world of Pennies <span class="w3-tag" style="margin-right: 45%;">Just Thrift It</span></h6>

  </header>

  <!-- Image header -->
  <header class="w3-display-container w3-wide" id="home">
    <img class="w3-image" src="images/logo.png" alt="Thift Store" width="800" height="100">
    <div class="w3-display-right w3-padding-large">
      <h1 class="w3-text-blue"></h1>
      <h1 class="w3-jumbo w3-text-blue w3-hide-small"><b>FASHION BLOG</b></h1>


      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
      <h6>
    <a href="http://localhost/TreasureHunt/shoppingcart/" class="w3-button w3-black  w3-opacity w3-hover-opacity-off">Continue Shopping in your Cart</i></a>
        </div>
      

 </div>
  </header>

  <!-- Grid -->
  <div class="w3-row w3-padding w3-border">

    <!-- Blog entries -->
    <div class="w3-col l8 s12">
    
      <!-- Blog entry -->
      <div class="w3-container w3-white w3-margin w3-padding-large">
        <div class="w3-center">
          <h3>Why US</h3>
          <h5>Dont Shop, <span class="w3-opacity">Thrift</span></h5>
        </div>

        <div class="w3-justify">
          <img class="w3-image" src="images/dress1.png"  alt="Date nights" style="width:100%" class="w3-padding-16">
          <p><strong>Why Thrift!</strong> We never know what we’re going to find at thrift shops, and we can get really cool items for a cheap price. Whether it’d be cute prom dress or a vintage watch
, it’s possible to make good use of something that was donated. 
Thrift shopping is good for the environment because it keeps clothes out of landfills, reduces carbon and chemical pollution caused by clothing production, and lowers water consumption. Most thrift shops also support local charities, which some could be for environmental causes.</p>
          <p class="w3-left"><button class="w3-button w3-white w3-border" onclick="likeFunction(this)"><b><i class="fa fa-thumbs-up"></i> Like</b></button></p>
          <p class="w3-right"><button class="w3-button w3-black" onclick="myFunction('demo1')" id="myBtn"><b>Replies  </b> <span class="w3-tag w3-white">1</span></button></p>
          <p class="w3-clear"></p>
          <div class="w3-row w3-margin-bottom" id="demo1" style="display:none">
            <hr>
              <div class="w3-col l2 m3">
                <img src="images/pic4.png" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>George <span class="w3-opacity w3-medium"></span></h4>
                <p>Great blog post! Following</p>
              </div>
          </div>
        </div>
      </div>
      <hr>

      <!-- Blog entry -->
      <div class="w3-container w3-white w3-margin w3-padding-large">
        <div class="w3-center">
          <h3>For MEN and Women</h3>
          <h5>There is room for groom and bride here, <span class="w3-opacity"></span></h5>
        </div>

        <div class="w3-justify">
          <img src="images/pic1.png" alt="Men in Hats" style="width:100%" class="w3-padding-16">
          <p><strong>Wedding Dress!</strong> We are here for Wedding Season</p>
          <p>.</p>
          <p class="w3-left"><button class="w3-button w3-white w3-border" onclick="likeFunction(this)"><b><i class="fa fa-thumbs-up"></i> Like</b></button></p>
          <p class="w3-right"><button class="w3-button w3-black" onclick="myFunction('demo2')"><b>Replies  </b> <span class="w3-tag w3-white">2</span></button></p>
          <p class="w3-clear"></p>
          
          <!-- Example of comment field -->
          <div id="demo2" style="display:none">
            <div class="w3-row">
              <hr>
              <div class="w3-col l2 m3">
                <img src="/w3images/girl_train.jpg" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>Amber <span class="w3-opacity w3-medium"></span></h4>
                <p>Love the dress.</p><br>
              </div>
            </div>
            <div class="w3-row w3-margin-bottom">
              <div class="w3-col l2 m3">
                <img src="/w3images/girl.jpg" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>Angie <span class="w3-opacity w3-medium"></span></h4>
                <p>Beautiful couple!!</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Blog entry -->
      <div class="w3-container w3-white w3-margin w3-padding-large">
        <div class="w3-center">
          <h3>Accessories</h3>
          <h5>Flaunt It, <span class="w3-opacity"></span></h5>
        </div>

        <div class="w3-justify">
          <img src="images/pic7.png" alt="Bag" style="width:100%" class="w3-padding-16">
          <p><strong>Dont miss!</strong> We have more than this!</p>
          <p>.</p>
          <p class="w3-left"><button class="w3-button w3-white w3-border" onclick="likeFunction(this)"><b><i class="fa fa-thumbs-up"></i> Like</b></button></p>
          <p class="w3-right"><button class="w3-button w3-black" onclick="myFunction('demo3')"><b>Replies  </b> <span class="w3-tag w3-white">3</span></button></p>
          <p class="w3-clear"></p>
          
          <!-- Example of comment field -->
          <div id="demo3" style="display:none">
            <hr>
            <div class="w3-row w3-margin-bottom">
              <div class="w3-col l2 m3">
                <img src="images/TreasureHuntLogo.png" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>Jane <span class="w3-opacity w3-medium"></span></h4>
                <p>That was a great runway show! Thanks for everything.</p>
              </div>
            </div>
            <div class="w3-row w3-margin-bottom">
              <div class="w3-col l2 m3">
                <img src="/w3images/boy.jpg" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>John <span class="w3-opacity w3-medium"></span></h4>
                <p>Keep up the GREAT work! I am cheering for you!! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
              </div>
            </div>
            <div class="w3-row w3-margin-bottom">
              <div class="w3-col l2 m3">
                <img src="/w3images/girl_hood.jpg" style="width:90px;">
              </div>
              <div class="w3-col l10 m9">
                <h4>Anja <span class="w3-opacity w3-medium"></span></h4>
                <p>Cant wait for the runway to start!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    <!-- END BLOG ENTRIES -->
    </div>

    <!-- About/Information menu -->
    <div class="w3-col l4">
      <!-- About Card -->
      <div class="w3-white w3-margin">
        <img src="images/TreasureHuntLogo.png" alt="Jane" style="width:100%" class="w3-grayscale">
        <div class="w3-container w3-black">
          <h4>Group-1</h4>
          <p>We are Prakriti, Priya, Dinesh and Ahmer. We have a heart of love and  share our  world with you.</p>
        </div>
      </div>
      <hr>

      <!-- Posts -->
      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Popular Posts</h4>
        </div>
        <ul class="w3-ul w3-hoverable w3-white">
          <li class="w3-padding-16">
            <img src="images/jeans.png" alt="Image" class="w3-left w3-margin-right" style="width:50px">
            <span class="w3-large">Denim</span>
 <li class="w3-padding-16">
            <br>
            
          </li>
          <li class="w3-padding-16">
            <img src="images/ahmer.jfif" alt="Image" class="w3-left w3-margin-right" style="width:50px">
            <span class="w3-large">Sweaters</span>
            <span..........</span>
 <li class="w3-padding-16">
            <br>
           
          </li>
          <li class="w3-padding-16">
            <img src="images/TreasureHuntlogo.png" alt="Image" class="w3-left w3-margin-right" style="width:50px">
            <span class="w3-large">Workshop</span>
            <span..............</span>
 <li class="w3-padding-16">
            <br>
            
          </li>
          <li class="w3-padding-16">
            <img src="images/pic4.png" alt="Image" class="w3-left w3-margin-right w3-sepia" style="width:50px">
            <span class="w3-large">Trends</span>
               <span..............</span>
            <br>
    
          </li>
        </ul>
      </div>
      <hr>

      <!-- Advertising -->
      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Check out this cute bag !</h4>
        </div>
        <div class="w3-container w3-white">
          <div class="w3-container w3-display-container w3-light-grey w3-section" style="height:100px">

          <img src="images/chanelbags.png" alt="Image" class="w3-left w3-margin-right w3-sepia" style="width:400px"> 
        <span class="w3-display-middle"> ON SALE</span>
          </div>
        </div>
      </div>
      <hr>

      <!-- Tags -->
      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Tags</h4>
        </div>
        <div class="w3-container w3-white">
          <p>
            <span class="w3-tag w3-black w3-margin-bottom">Fashion</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">New York</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">London</span>
            <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Hats</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Norway</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Sweaters</span>
            <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Ideas</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Deals</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Accessories</span>
            <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">News</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Clothing</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Shopping</span>
            <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Jeans</span> <span class="w3-tag w3-light-grey w3-small w3-margin-bottom">Trends</span>
          </p>
        </div>
      </div>
      <hr>

      <!-- Inspiration -->
      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Inspiration</h4>
        </div>
        <div class="w3-row-padding w3-white">
          <div class="w3-col s6">
            <p><img src="images/pic5.png" alt="Jeans" style="width:100%"></p>
            <p><img src="images/pic6.png" alt="Jeans" style="width:100%"></p>
          </div>
          <div class="w3-col s6">
            <p><img src="images/pic3.png" alt="Men in Hats" style="width:100%" class="w3-grayscale"></p>
            <p><img src="images/pic2.png" alt="Jeans" style="width:100%"></p>
         </div>
        </div>
      </div>
      <hr>

      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Follow Me</h4>
        </div>
        <div class="w3-container w3-xlarge w3-padding">
          <i class="fa fa-facebook-official w3-hover-opacity"></i>
          <i class="fa fa-instagram w3-hover-opacity"></i>
          <i class="fa fa-snapchat w3-hover-opacity"></i>
          <i class="fa fa-pinterest-p w3-hover-opacity"></i>
          <i class="fa fa-twitter w3-hover-opacity"></i>
          <i class="fa fa-linkedin w3-hover-opacity"></i>
        </div>
      </div>
      <hr>
      
      <!-- Newsletters -->
      <div class="w3-white w3-margin">
        <div class="w3-container w3-padding w3-black">
          <h4>Newsletters</h4>
        </div>
        <div class="w3-container w3-white">
          <p>Enter your e-mail below and get notified on the latest blog posts.</p>
          <p><input class="w3-input w3-border" type="text" placeholder="Enter e-mail" style="width:100%"></p>
          <p><button type="button" onclick="document.getElementById('newsletters').style.display='block'" class="w3-button w3-block w3-red">Newsletters</button></p>
        </div>
      </div>
 


    <!-- END About/Intro Menu -->
    </div>

  <!-- END GRID -->
  </div>

<!-- END w3-content -->
</div>

<!-- Newsletters Modal -->
<div id="newsletters" class="w3-modal w3-animate-opacity">
  <div class="w3-modal-content" style="padding:32px">
    <div class="w3-container w3-white">
      <i onclick="document.getElementById('newsletters').style.display='none'" class="fa fa-remove w3-transparent w3-button w3-xlarge w3-right"></i>
      <h2 class="w3-wide">Newsletters</h2>
      <p>Join my mailing list to receive updates on the latest blog posts and other things.</p>
      <p><input class="w3-input w3-border" type="text"  value="admin" placeholder="Enter e-mail"></p>
      <button type="button" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletters').style.display='none'">Newsletters</button>
    </div>
  </div>
</div>







        </script>

</div>
  </div>
</div>


<!-- CUSTOMER LOG IN Modal -->

<div id="customerlogin" class="w3-modal w3-animate-opacity" >
  <div class="w3-modal-content" style="padding:32px">
    <div class="w3-container w3-white">
      <i onclick="document.getElementById('customerlogin').style.display='none'" class="fa fa-remove w3-transparent w3-button w3-xlarge w3-right"></i>
      <h2 class="w3-wide">LOG IN</h2>
      <p>LOG IN to your account.</p>
      <p><input class="w3-input w3-border" type="text" placeholder="Enter your Username" id="username"></p>
<p><input class="w3-input w3-border" type="password"   placeholder="Enter password"></p>
 <a href="http://localhost/TreasureHunt/customer.php" class="w3-button w3-black  w3-opacity w3-hover-opacity-off">LOG IN </i></a>
    


</div>
  </div>
</div>
