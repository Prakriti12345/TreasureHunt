<!DOCTYPE html>
<html>
<head>

</head>
<body>
<centre>


<?php



$conn = mysqli_connect('localhost', 'root', '','treasurehunt');

if($conn === false){
die("ERROR".mysqli_connect_error());}


$Email = mysqli_real_escape_string($conn, $_POST["Email"]);
$Password = mysqli_real_escape_string($conn, $_POST["Password"]);



// database insert SQL code
$sql = "INSERT INTO login  (Email, Password) VALUES ('$Email', '$Password')";

  
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>