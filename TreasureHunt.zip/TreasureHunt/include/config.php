<?php

$host="localhost";
$username="root";
$password="";
$database= "treasurehunt";


// get the post records
//$FirstName = $_POST['fn'];
//$LastName = $_POST['ln'];
//$Username = $_POST['un'];
//$Email = $_POST['email'];
//$birthday = $_POST['bday'];
//$PhoneNumber = $_POST['phone'];
//Password = $_POST['psw'];
//$RepeatPassword = $_POST['psw-repeat'];
//$Address= $_POST['address-line1'];
//$ZIP= $_POST['postal-code'];
//$Country = $_POST['country'];


$sql = mysqli_connect($host, $username, $password, $database) or die ('could not connect');


?>